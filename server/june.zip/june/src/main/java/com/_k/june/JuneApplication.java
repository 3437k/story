package com._k.june;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JuneApplication {

	public static void main(String[] args) {
		SpringApplication.run(JuneApplication.class, args);
	}

}
