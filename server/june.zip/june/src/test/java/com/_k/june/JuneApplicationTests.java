package com._k.june;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JuneApplicationTests {

	@Test
	void contextLoads() {
	}

}
